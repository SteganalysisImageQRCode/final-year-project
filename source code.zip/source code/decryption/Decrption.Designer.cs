﻿namespace imgefile
{
    partial class q2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.qrimg = new System.Windows.Forms.PictureBox();
            this.label2 = new System.Windows.Forms.Label();
            this.img_bt = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.openfilebt = new System.Windows.Forms.Button();
            this.filepath = new System.Windows.Forms.TextBox();
            this.get_image_from_qr = new System.Windows.Forms.Button();
            this.contextMenuStrip1 = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.ulr_image = new System.Windows.Forms.PictureBox();
            this.URL_tx = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.Decryption_bt = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.qrimg)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ulr_image)).BeginInit();
            this.SuspendLayout();
            // 
            // qrimg
            // 
            this.qrimg.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.qrimg.Location = new System.Drawing.Point(106, 91);
            this.qrimg.Name = "qrimg";
            this.qrimg.Size = new System.Drawing.Size(200, 200);
            this.qrimg.TabIndex = 34;
            this.qrimg.TabStop = false;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(103, 67);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(88, 13);
            this.label2.TabIndex = 33;
            this.label2.Text = "Select QR Image";
            // 
            // img_bt
            // 
            this.img_bt.Location = new System.Drawing.Point(197, 62);
            this.img_bt.Name = "img_bt";
            this.img_bt.Size = new System.Drawing.Size(75, 23);
            this.img_bt.TabIndex = 32;
            this.img_bt.Text = "open image";
            this.img_bt.UseVisualStyleBackColor = true;
            this.img_bt.Click += new System.EventHandler(this.img_bt_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(103, 10);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(107, 13);
            this.label1.TabIndex = 31;
            this.label1.Text = "Select Encrypted File";
            // 
            // openfilebt
            // 
            this.openfilebt.Location = new System.Drawing.Point(529, 23);
            this.openfilebt.Name = "openfilebt";
            this.openfilebt.Size = new System.Drawing.Size(75, 23);
            this.openfilebt.TabIndex = 30;
            this.openfilebt.Text = "open file";
            this.openfilebt.UseVisualStyleBackColor = true;
            this.openfilebt.Click += new System.EventHandler(this.openfilebt_Click);
            // 
            // filepath
            // 
            this.filepath.Location = new System.Drawing.Point(103, 26);
            this.filepath.Name = "filepath";
            this.filepath.Size = new System.Drawing.Size(420, 20);
            this.filepath.TabIndex = 29;
            // 
            // get_image_from_qr
            // 
            this.get_image_from_qr.Location = new System.Drawing.Point(104, 297);
            this.get_image_from_qr.Name = "get_image_from_qr";
            this.get_image_from_qr.Size = new System.Drawing.Size(202, 23);
            this.get_image_from_qr.TabIndex = 37;
            this.get_image_from_qr.Text = "Get URL";
            this.get_image_from_qr.UseVisualStyleBackColor = true;
            this.get_image_from_qr.Click += new System.EventHandler(this.get_image_from_qr_Click);
            // 
            // contextMenuStrip1
            // 
            this.contextMenuStrip1.Name = "contextMenuStrip1";
            this.contextMenuStrip1.Size = new System.Drawing.Size(61, 4);
            // 
            // ulr_image
            // 
            this.ulr_image.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ulr_image.Location = new System.Drawing.Point(365, 113);
            this.ulr_image.Name = "ulr_image";
            this.ulr_image.Size = new System.Drawing.Size(381, 178);
            this.ulr_image.TabIndex = 38;
            this.ulr_image.TabStop = false;
            // 
            // URL_tx
            // 
            this.URL_tx.Location = new System.Drawing.Point(365, 91);
            this.URL_tx.Name = "URL_tx";
            this.URL_tx.Size = new System.Drawing.Size(262, 20);
            this.URL_tx.TabIndex = 39;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(362, 72);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(61, 13);
            this.label3.TabIndex = 40;
            this.label3.Text = "Image URL";
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(633, 88);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(113, 23);
            this.button1.TabIndex = 41;
            this.button1.Text = "Get Image from URL";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // Decryption_bt
            // 
            this.Decryption_bt.Location = new System.Drawing.Point(106, 336);
            this.Decryption_bt.Name = "Decryption_bt";
            this.Decryption_bt.Size = new System.Drawing.Size(640, 23);
            this.Decryption_bt.TabIndex = 42;
            this.Decryption_bt.Text = "Decryption";
            this.Decryption_bt.UseVisualStyleBackColor = true;
            this.Decryption_bt.Click += new System.EventHandler(this.Decryption_bt_Click);
            // 
            // q2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(759, 582);
            this.Controls.Add(this.Decryption_bt);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.URL_tx);
            this.Controls.Add(this.ulr_image);
            this.Controls.Add(this.get_image_from_qr);
            this.Controls.Add(this.qrimg);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.img_bt);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.openfilebt);
            this.Controls.Add(this.filepath);
            this.Name = "q2";
            this.Text = "Decryption";
            ((System.ComponentModel.ISupportInitialize)(this.qrimg)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ulr_image)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.PictureBox qrimg;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button img_bt;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button openfilebt;
        private System.Windows.Forms.TextBox filepath;
        private System.Windows.Forms.Button get_image_from_qr;
        private System.Windows.Forms.ContextMenuStrip contextMenuStrip1;
        private System.Windows.Forms.PictureBox ulr_image;
        private System.Windows.Forms.TextBox URL_tx;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button Decryption_bt;
    }
}