﻿using System;

namespace imgefile
{
    partial class Encryption
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label4 = new System.Windows.Forms.Label();
            this.pw_tx = new System.Windows.Forms.TextBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.label3 = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.outputpath = new System.Windows.Forms.TextBox();
            this.Encryption_bt = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.img_bt = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.openfilebt = new System.Windows.Forms.Button();
            this.filepath = new System.Windows.Forms.TextBox();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.SuspendLayout();
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(124, 355);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(53, 13);
            this.label4.TabIndex = 28;
            this.label4.Text = "Password";
            // 
            // pw_tx
            // 
            this.pw_tx.Location = new System.Drawing.Point(124, 374);
            this.pw_tx.Name = "pw_tx";
            this.pw_tx.PasswordChar = '*';
            this.pw_tx.Size = new System.Drawing.Size(501, 20);
            this.pw_tx.TabIndex = 27;
            this.pw_tx.TextChanged += new System.EventHandler(this.pw_tx_TextChanged);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Location = new System.Drawing.Point(125, 87);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(499, 248);
            this.pictureBox1.TabIndex = 26;
            this.pictureBox1.TabStop = false;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(127, 421);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(83, 13);
            this.label3.TabIndex = 25;
            this.label3.Text = "Output Location";
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(550, 437);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 23);
            this.button1.TabIndex = 24;
            this.button1.Text = "open file";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // outputpath
            // 
            this.outputpath.Location = new System.Drawing.Point(124, 440);
            this.outputpath.Name = "outputpath";
            this.outputpath.Size = new System.Drawing.Size(420, 20);
            this.outputpath.TabIndex = 23;
            // 
            // Encryption_bt
            // 
            this.Encryption_bt.Location = new System.Drawing.Point(124, 486);
            this.Encryption_bt.Name = "Encryption_bt";
            this.Encryption_bt.Size = new System.Drawing.Size(498, 23);
            this.Encryption_bt.TabIndex = 22;
            this.Encryption_bt.Text = "Encryption";
            this.Encryption_bt.UseVisualStyleBackColor = true;
            this.Encryption_bt.Click += new System.EventHandler(this.Encryption_bt_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(126, 71);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(63, 13);
            this.label2.TabIndex = 21;
            this.label2.Text = "Input Image";
            // 
            // img_bt
            // 
            this.img_bt.Location = new System.Drawing.Point(195, 66);
            this.img_bt.Name = "img_bt";
            this.img_bt.Size = new System.Drawing.Size(111, 23);
            this.img_bt.TabIndex = 20;
            this.img_bt.Text = "Select Image";
            this.img_bt.UseVisualStyleBackColor = true;
            this.img_bt.Click += new System.EventHandler(this.img_bt_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(126, 14);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(50, 13);
            this.label1.TabIndex = 19;
            this.label1.Text = "Input File";
            // 
            // openfilebt
            // 
            this.openfilebt.Location = new System.Drawing.Point(552, 27);
            this.openfilebt.Name = "openfilebt";
            this.openfilebt.Size = new System.Drawing.Size(75, 23);
            this.openfilebt.TabIndex = 18;
            this.openfilebt.Text = "Select File";
            this.openfilebt.UseVisualStyleBackColor = true;
            this.openfilebt.Click += new System.EventHandler(this.openfilebt_Click);
            // 
            // filepath
            // 
            this.filepath.Location = new System.Drawing.Point(126, 30);
            this.filepath.Name = "filepath";
            this.filepath.Size = new System.Drawing.Size(420, 20);
            this.filepath.TabIndex = 17;
            // 
            // pictureBox2
            // 
            this.pictureBox2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureBox2.Location = new System.Drawing.Point(680, 309);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(200, 200);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox2.TabIndex = 29;
            this.pictureBox2.TabStop = false;
            // 
            // Encryption
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1164, 741);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.pw_tx);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.outputpath);
            this.Controls.Add(this.Encryption_bt);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.img_bt);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.openfilebt);
            this.Controls.Add(this.filepath);
            this.Name = "Encryption";
            this.Text = "Encryption";
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        private void button1_Click(object sender, EventArgs e)
        {
            throw new NotImplementedException();
        }

        #endregion

        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox pw_tx;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.TextBox outputpath;
        private System.Windows.Forms.Button Encryption_bt;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button img_bt;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button openfilebt;
        private System.Windows.Forms.TextBox filepath;
        private System.Windows.Forms.PictureBox pictureBox2;
    }
}