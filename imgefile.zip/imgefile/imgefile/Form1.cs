﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Security.Cryptography;
using System.Security;
using System.Runtime.InteropServices;
using System.Text.RegularExpressions;
using System.IO;
using System.Drawing.Imaging;

namespace imgefile
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void openfilebt_Click(object sender, EventArgs e)
        {
            OpenFileDialog fdlg = new OpenFileDialog();
            fdlg.Title = "Open File Dialog";
            fdlg.InitialDirectory = @"c:\";
            fdlg.Filter = "All files (*.*)|*.*|All files (*.*)|*.*";
            fdlg.FilterIndex = 2;
            fdlg.RestoreDirectory = true;
            if (fdlg.ShowDialog() == DialogResult.OK)
            {
                filepath.Text = fdlg.FileName;
            }
        }

        private void Encryption_bt_Click(object sender, EventArgs e)
        {
            try
            {
                string embtext = pw_tx.Text;
              //  string password = @"myKey123"; // Your Key Here
                string password = pw_tx.Text; // Your Key Here
                UnicodeEncoding UE = new UnicodeEncoding();
                byte[] key = UE.GetBytes(password);

                string cryptFile = outputpath.Text;
                FileStream fsCrypt = new FileStream(cryptFile, FileMode.Create);

                RijndaelManaged RMCrypto = new RijndaelManaged();

                CryptoStream cs = new CryptoStream(fsCrypt,
                    RMCrypto.CreateEncryptor(key, key),
                    CryptoStreamMode.Write);

                FileStream fsIn = new FileStream(filepath.Text, FileMode.Open);

                int data;
                while ((data = fsIn.ReadByte()) != -1)
                    cs.WriteByte((byte)data);


                fsIn.Close();
                cs.Close();
                fsCrypt.Close();

                Bitmap img = (Bitmap)pictureBox1.BackgroundImage;
               
                string Steg_pw = "123";

                if (string.IsNullOrEmpty(embtext))
                {
                    MessageBox.Show("Empty string can't be hide", "Warning");
                    return;
                }

                if (string.IsNullOrEmpty(Steg_pw))
                {
                    MessageBox.Show("Password can't be empty", "Warning");
                    return;
                }

                try
                {
                    embtext = RijndaelAlgo.Encrypt(embtext, Steg_pw);
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }

                img = SteganographyHelper.MergeText(embtext, img);

                SaveFileDialog sav = new SaveFileDialog();
                sav.Filter = "Png Image|*.png|Bitmap Image|*.bmp";

                if (sav.ShowDialog() == DialogResult.OK)
                {
                    switch (sav.FilterIndex)
                    {
                        case 0:
                            {
                                img.Save(sav.FileName, ImageFormat.Png);
                            }
                            break;
                        case 1:
                            {
                                img.Save(sav.FileName, ImageFormat.Bmp);
                            }
                            break;
                    }
                }

                MessageBox.Show("Information hided successfully", "Information");
            
            }
            catch
            {
                MessageBox.Show("Encryption failed!", "Error");
            }
        }

        private void decryption_bt_Click(object sender, EventArgs e)
        {
            Bitmap img = (Bitmap)pictureBox1.BackgroundImage;
            string Steg_pw = "123";
           // Bitmap img = RecoverImage((Bitmap)pictureBox1.BackgroundImage, 4);


            string extractString = SteganographyHelper.ExtractText(img);
            if (string.IsNullOrEmpty(Steg_pw))
            {
                MessageBox.Show("Please specify the password, To Extract the information.", "Security");
                return;
            }
            
                extractString = RijndaelAlgo.Decrypt(extractString, Steg_pw);
            try
            {

            }
            catch (Exception ex)
            {
                MessageBox.Show("Wrong password", "Error");
                return;
            }
            pw_tx.Text = extractString;
            {
                string inputFile = filepath.Text;
                string outputFile = outputpath.Text;
                string password = pw_tx.Text; // Your Key Here

                UnicodeEncoding UE = new UnicodeEncoding();
                byte[] key = UE.GetBytes(password);

                FileStream fsCrypt = new FileStream(inputFile, FileMode.Open);

                RijndaelManaged RMCrypto = new RijndaelManaged();

                CryptoStream cs = new CryptoStream(fsCrypt,
                    RMCrypto.CreateDecryptor(key, key),
                    CryptoStreamMode.Read);

                FileStream fsOut = new FileStream(outputFile, FileMode.Create);

                int data;
                while ((data = cs.ReadByte()) != -1)
                    fsOut.WriteByte((byte)data);

                fsOut.Close();
                cs.Close();
                fsCrypt.Close();

            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            OpenFileDialog openfile = new OpenFileDialog();
            openfile.Filter = "Image Files (*.jpeg; *.png; *.bmp)|*.jpg; *.png; *.bmp";
            openfile.Multiselect = false;
            openfile.ShowDialog();
            if (!String.IsNullOrEmpty(openfile.FileName))
            {
                pictureBox2.BackgroundImage = Image.FromFile(openfile.FileName);
            }

        }

        private void button3_Click(object sender, EventArgs e)
        {
            OpenFileDialog openfile = new OpenFileDialog();
            openfile.Filter = "Image Files (*.jpeg; *.png; *.bmp)|*.jpg; *.png; *.bmp";
            openfile.Multiselect = false;
            openfile.ShowDialog();
            if (!String.IsNullOrEmpty(openfile.FileName))
            {
                pictureBox3.BackgroundImage = Image.FromFile(openfile.FileName);
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            Cursor = Cursors.WaitCursor;
            int num_bits = 4;
            Bitmap vis = (Bitmap)pictureBox2.BackgroundImage;
            Bitmap hid = (Bitmap)pictureBox3.BackgroundImage;
            pictureBox4.BackgroundImage=HideImage(vis, hid, num_bits);

            Cursor = Cursors.Default;
        }
        private void button5_Click(object sender, EventArgs e)
        {
            Bitmap img= (Bitmap)pictureBox4.BackgroundImage;
           

            SaveFileDialog sav = new SaveFileDialog();
            sav.Filter = "Png Image|*.png|Bitmap Image|*.bmp";

            if (sav.ShowDialog() == DialogResult.OK)
            {
                switch (sav.FilterIndex)
                {
                    case 0:
                        {
                            img.Save(sav.FileName, ImageFormat.Png);
                        }
                        break;
                    case 1:
                        {
                            img.Save(sav.FileName, ImageFormat.Bmp);
                        }
                        break;
                }
            }

            MessageBox.Show("Information hided successfully", "Information");
        }
        public static Bitmap HideImage(Bitmap bm_visible, Bitmap bm_hidden, int hidden_bits)
        {
            int shift = (8 - hidden_bits);
            int visible_mask = 0xFF << hidden_bits;
            int hidden_mask = 0xFF >> shift;
            Bitmap bm_combined = new Bitmap(bm_visible.Width,
                bm_visible.Height);
            for (int x = 0; x < bm_visible.Width; x++)
            {
                for (int y = 0; y < bm_visible.Height; y++)
                {
                    Color clr_visible = bm_visible.GetPixel(x, y);
                    Color clr_hidden = bm_hidden.GetPixel(x, y);
                    int r = (clr_visible.R & visible_mask) +
                        ((clr_hidden.R >> shift) & hidden_mask);
                    int g = (clr_visible.G & visible_mask) +
                        ((clr_hidden.G >> shift) & hidden_mask);
                    int b = (clr_visible.B & visible_mask) +
                        ((clr_hidden.B >> shift) & hidden_mask);
                    bm_combined.SetPixel(x, y,
                        Color.FromArgb(255, r, g, b));
                }
            }
            return bm_combined;
        }
        public static Bitmap RecoverImage(Bitmap bm_combined,int hidden_bits)
        {
            int shift = (8 - hidden_bits);
            int hidden_mask = 0xFF >> shift;
            Bitmap bm_hidden = new Bitmap(bm_combined.Width,bm_combined.Height);
            for (int x = 0; x < bm_combined.Width; x++)
            {
                for (int y = 0; y < bm_combined.Height; y++)
                {
                    Color clr_combined = bm_combined.GetPixel(x, y);
                    int r = (clr_combined.R & hidden_mask) << shift;
                    int g = (clr_combined.G & hidden_mask) << shift;
                    int b = (clr_combined.B & hidden_mask) << shift;
                    bm_hidden.SetPixel(x, y, Color.FromArgb(255, r, g, b));
                }
            }
            return bm_hidden;
        }
        private void endripToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Encryption_bt.Visible = true;
            decryption_bt.Visible = false;
        }

        private void img_bt_Click(object sender, EventArgs e)
        {
            OpenFileDialog openfile = new OpenFileDialog();
            openfile.Filter = "Image Files (*.jpeg; *.png; *.bmp)|*.jpg; *.png; *.bmp";
            openfile.Multiselect = false;
            openfile.ShowDialog();
            if (!String.IsNullOrEmpty(openfile.FileName))
            {
                pictureBox1.BackgroundImage = Image.FromFile(openfile.FileName);
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            FolderBrowserDialog folderDlg = new FolderBrowserDialog();
            folderDlg.ShowNewFolderButton = true;
            // Show the FolderBrowserDialog.  
            DialogResult result = folderDlg.ShowDialog();
            if (result == DialogResult.OK)
            {
                outputpath.Text = folderDlg.SelectedPath;
                Environment.SpecialFolder root = folderDlg.RootFolder;
            }
        }

        private void button6_Click(object sender, EventArgs e)
        {
            OpenFileDialog openfile = new OpenFileDialog();
            openfile.Filter = "Image Files (*.jpeg; *.png; *.bmp)|*.jpg; *.png; *.bmp";
            openfile.Multiselect = false;
            openfile.ShowDialog();
            if (!String.IsNullOrEmpty(openfile.FileName))
            {
                pictureBox4.BackgroundImage = Image.FromFile(openfile.FileName);
            }
        }

        private void button7_Click(object sender, EventArgs e)
        {
            Bitmap img = (Bitmap)pictureBox4.BackgroundImage;
            int hidden_bits = 4;
            pictureBox2.BackgroundImage = RecoverImage(img, hidden_bits);
            
        }


        private void button8_Click(object sender, EventArgs e)
        {
              Byte[] result = (Byte[])new ImageConverter().ConvertTo(pictureBox4.BackgroundImage, typeof(Byte[]));
            // Convert byte[] to Base64 String
            string base64String = Convert.ToBase64String(result);
            textBox1.Text = base64String;
            textBox2.Text = (base64String.Length).ToString();
            
           
          
        }
        public byte[] ToHexBytes(string hex)
        {
            if (hex == null) return null;
            if (hex.Length == 0) return new byte[0];

            int l = hex.Length / 2;
            var b = new byte[l];
            for (int i = 0; i < l; ++i)
            {
                b[i] = Convert.ToByte(hex.Substring(i * 2, 2), 16);
            }
            return b;
        }

        private void imageCloudOptionToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }
    }
}
