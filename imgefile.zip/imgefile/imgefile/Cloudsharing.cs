﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace imgefile
{
    public partial class Cloudsharing : Form
    {
        SqlConnection con = new SqlConnection(@" Data Source=.\SQLEXPRESS;Initial Catalog=filemrg;Integrated Security=True;MultipleActiveResultSets=True");

        public Cloudsharing()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                
                if (con.State == ConnectionState.Closed)
                {
                    con.Open();
                }
                // // IF EXISTS (select * from clouddetails) then update clouddetails set webaddress=@webaddress else INSERT INTO clouddetails (webaddress)VALUES (@webaddress)

                string sql = " IF EXISTS (select * from clouddetails) BEGIN update clouddetails set webaddress=@webaddress END else BEGIN INSERT INTO clouddetails (webaddress)VALUES (@webaddress) END";
            SqlCommand cmd = new SqlCommand(sql, con);
            //@client_name,@address_1,@address_2,@state,pin,@gst_no,@pan_no
            cmd.Parameters.AddWithValue("@webaddress", address_tx.Text);
         
            cmd.ExecuteNonQuery();
            con.Close();
            MessageBox.Show("saved");
            }
            catch (Exception ex)
            {
                MessageBox.Show("Can not open connection1 s! " + ex);
            }
            finally
            {
                con.Close();
            }
        }
    }
}
